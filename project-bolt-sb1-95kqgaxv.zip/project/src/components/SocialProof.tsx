import { Quote } from 'lucide-react';

export default function SocialProof() {
  const testimonials = [
    {
      text: 'Antes eu vivia perdida com prazos. Hoje entro no UGC Control e sei exatamente o que fazer.',
      author: 'Criadora UGC',
      image: '/91c2fda4b1b4f169959331e2f07e409e.jpg'
    },
    {
      text: 'O UGC Control virou meu QG de trabalho.',
      author: 'Criadora UGC',
      image: '/download.jpg'
    },
    {
      text: 'Só o controle de prazos já mudou minha rotina.',
      author: 'Criadora iniciante',
      image: '/91c2fda4b1b4f169959331e2f07e409e.jpg'
    }
  ];

  return (
    <section className="relative py-24 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-rose-950/10 to-gray-950" />

      <div className="relative max-w-6xl mx-auto z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-6 text-white">
          Criadoras já estão <span className="text-rose-400">transformando</span> sua rotina
        </h2>
        <p className="text-xl text-gray-300 text-center mb-16 max-w-2xl mx-auto">
          Veja o que quem já usa o UGC Control tem a dizer
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-rose-900/10 via-purple-900/10 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-rose-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-rose-500/20"
            >
              <Quote className="w-10 h-10 text-rose-400 mb-6 opacity-50" />
              <p className="text-gray-200 text-lg mb-6 leading-relaxed italic">
                "{testimonial.text}"
              </p>
              <div className="flex items-center gap-3">
                <img
                  src={testimonial.image}
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover border border-rose-400/30"
                />
                <div>
                  <p className="text-white font-semibold">{testimonial.author}</p>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-rose-400">★</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
