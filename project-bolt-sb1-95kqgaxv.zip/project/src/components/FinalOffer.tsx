import { ArrowRight, Shield, Zap, Heart } from 'lucide-react';

interface FinalOfferProps {
  onCtaClick: () => void;
}

export default function FinalOffer({ onCtaClick }: FinalOfferProps) {
  return (
    <section className="relative py-32 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-purple-900/30 to-rose-900/30" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(120,40,80,0.2),transparent_70%)]" />

      <div className="relative max-w-4xl mx-auto text-center z-10">
        <div className="inline-flex items-center gap-2 bg-rose-500/20 border border-rose-500/30 rounded-full px-6 py-2 mb-8">
          <Zap className="w-5 h-5 text-rose-400" />
          <span className="text-rose-300 font-semibold">Oferta Especial</span>
        </div>

        <h2 className="text-5xl md:text-6xl font-bold mb-6 text-white">
          Acesse o <span className="bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent">UGC Control</span> hoje
        </h2>

        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
          Organize seus jobs, prazos, marcas e ganhos em um sistema criado exclusivamente para criadoras UGC.
        </p>

        <div className="mb-8">
          <p className="text-gray-400 text-lg mb-2">Apenas por</p>
          <div className="text-6xl font-bold text-white mb-2">
            R$ <span className="bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent">19,90</span>
          </div>
          <p className="text-rose-300 font-semibold text-lg">/mês - Acesso imediato</p>
        </div>

        <button
          onClick={onCtaClick}
          className="group relative inline-flex items-center gap-3 px-10 py-6 bg-gradient-to-r from-rose-500 to-purple-600 text-white text-xl font-bold rounded-full hover:shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 animate-pulse-glow mb-12"
        >
          Acessar o UGC Control agora
          <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
        </button>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-gray-300">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-purple-400" />
            <span>Pagamento Seguro</span>
          </div>
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-rose-400" />
            <span>Acesso Instantâneo</span>
          </div>
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-purple-400" />
            <span>Feito por Criadoras</span>
          </div>
        </div>
      </div>
    </section>
  );
}
