import { Calendar, Briefcase, Wallet, Sparkles, Image } from 'lucide-react';

export default function Solution() {
  const features = [
    {
      icon: Calendar,
      title: 'Controle de prazos e entregas',
      description: 'Nunca mais perca um deadline. Veja todos os seus prazos organizados em um só lugar.'
    },
    {
      icon: Briefcase,
      title: 'Gestão de jobs e marcas',
      description: 'Acompanhe todos os seus projetos e mantenha o relacionamento com marcas organizado.'
    },
    {
      icon: Wallet,
      title: 'Financeiro organizado',
      description: 'Controle valores a receber, ganhos mensais e tenha clareza sobre seu faturamento.'
    },
    {
      icon: Sparkles,
      title: 'Geração de roteiros com IA',
      description: 'Crie roteiros profissionais para seus UGCs com ajuda de inteligência artificial.'
    },
    {
      icon: Image,
      title: 'Portfólio profissional',
      description: 'Organize seus melhores trabalhos e apresente-se de forma profissional para marcas.'
    }
  ];

  return (
    <section className="relative py-24 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-950 via-purple-950/20 to-gray-950" />

      <div className="relative max-w-6xl mx-auto z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-6 text-white">
          Tudo o que uma criadora UGC precisa,
        </h2>
        <p className="text-2xl text-center mb-16 bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent font-semibold">
          em um único painel.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group bg-gradient-to-br from-rose-900/10 via-purple-900/10 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-8 hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/20 hover:-translate-y-1"
              >
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-rose-500/20 to-purple-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Icon className="w-7 h-7 text-purple-300" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
