import { AlertCircle, Clock, DollarSign, FolderX, MessageSquare, Frown } from 'lucide-react';

export default function PainPoints() {
  const pains = [
    {
      icon: MessageSquare,
      text: 'Prazos espalhados no WhatsApp'
    },
    {
      icon: AlertCircle,
      text: 'Jobs esquecidos'
    },
    {
      icon: DollarSign,
      text: 'Falta de controle financeiro'
    },
    {
      icon: FolderX,
      text: 'Portfólio desorganizado'
    },
    {
      icon: Frown,
      text: 'Ansiedade constante com entregas'
    }
  ];

  return (
    <section className="relative py-24 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-950" />

      <div className="relative max-w-6xl mx-auto z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-white">
          Criar UGC não deveria ser <span className="text-rose-400">caótico.</span>
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pains.map((pain, index) => {
            const Icon = pain.icon;
            return (
              <div
                key={index}
                className="group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 hover:border-rose-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-rose-500/10"
              >
                <Icon className="w-8 h-8 text-rose-400 mb-4 group-hover:scale-110 transition-transform" />
                <p className="text-gray-200 text-lg font-medium">{pain.text}</p>
              </div>
            );
          })}

          <div className="md:col-span-2 lg:col-span-3 text-center mt-12">
            <p className="text-2xl md:text-3xl text-gray-300 font-light mb-12">
              É hora de <span className="text-purple-300 font-semibold">transformar o caos em controle.</span>
            </p>

            <div className="flex justify-center px-4">
              <div className="w-full max-w-2xl animate-float">
                <img
                  src="/captura_de_tela_2025-12-16_213753.png"
                  alt="Dashboard do UGC Control"
                  className="w-full h-auto rounded-2xl shadow-2xl shadow-purple-500/30 border border-purple-500/20"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
