export default function Footer() {
  return (
    <footer className="relative py-12 px-4 border-t border-gray-800">
      <div className="absolute inset-0 bg-gray-950" />

      <div className="relative max-w-6xl mx-auto z-10">
        <div className="text-center">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent mb-4">
            UGC Control
          </h3>
          <p className="text-gray-400 mb-6">
            O painel definitivo para criadoras UGC organizarem sua rotina profissional
          </p>
          <p className="text-gray-500 text-sm">
            © 2024 UGC Control. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
