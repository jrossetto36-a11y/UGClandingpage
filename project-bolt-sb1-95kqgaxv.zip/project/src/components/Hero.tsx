import { ArrowRight, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onCtaClick: () => void;
}

export default function Hero({ onCtaClick }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-purple-900/20 to-rose-900/30" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(120,40,80,0.15),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(80,40,120,0.15),transparent_50%)]" />

      <div className="relative max-w-5xl mx-auto text-center z-10">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          <span className="bg-gradient-to-r from-rose-300 via-purple-300 to-rose-300 bg-clip-text text-transparent">
            Controle sua vida UGC em um só lugar.
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
          O UGC Control é o painel feito para criadoras que querem organizar entregas, prazos, marcas e ganhos — sem planilhas, sem caos e sem estresse.
        </p>

        <button
          onClick={onCtaClick}
          className="group relative inline-flex items-center gap-3 px-8 py-5 bg-gradient-to-r from-rose-500 to-purple-600 text-white text-lg font-semibold rounded-full hover:shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 animate-pulse-glow"
        >
          Quero organizar minha vida UGC agora
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4 text-gray-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-rose-400" />
            <span>Acesso imediato</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-rose-400" />
            <span>Funciona no celular e no computador</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-rose-400" />
            <span>Feito para criadoras UGC</span>
          </div>
        </div>
      </div>
    </section>
  );
}
