import { CheckCircle2, Video, TrendingUp } from 'lucide-react';

export default function TargetAudience() {
  const audience = [
    'Criadoras UGC iniciantes ou avançadas',
    'Quem trabalha com Reels, TikTok e Ads',
    'Quem quer mais organização e profissionalismo'
  ];

  return (
    <section className="relative py-24 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-950 to-gray-900" />

      <div className="relative max-w-5xl mx-auto z-10">
        <div className="bg-gradient-to-br from-rose-900/20 via-purple-900/20 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-3xl p-12">
          <div className="flex justify-center gap-6 mb-8">
            <Video className="w-12 h-12 text-rose-400" />
            <TrendingUp className="w-12 h-12 text-purple-400" />
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-center mb-6 text-white">
            O UGC Control é para criadoras que querem
          </h2>
          <p className="text-2xl text-center mb-12 bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent font-semibold">
            crescer sem perder o controle.
          </p>

          <div className="max-w-2xl mx-auto space-y-4">
            {audience.map((item, index) => (
              <div
                key={index}
                className="flex items-start gap-4 bg-gray-900/50 rounded-2xl p-6 border border-gray-700/30"
              >
                <CheckCircle2 className="w-6 h-6 text-rose-400 flex-shrink-0 mt-1" />
                <p className="text-gray-200 text-lg font-medium">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
