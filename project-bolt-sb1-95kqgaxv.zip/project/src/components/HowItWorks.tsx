import { CreditCard, Mail, UserPlus, Layout, Sparkles } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: CreditCard,
      title: 'Faça o pagamento',
      description: 'Processo seguro e rápido'
    },
    {
      icon: Mail,
      title: 'Receba o acesso por e-mail',
      description: 'Instruções completas na sua caixa de entrada'
    },
    {
      icon: UserPlus,
      title: 'Crie seu login e senha',
      description: 'Configure sua conta em minutos'
    },
    {
      icon: Layout,
      title: 'Acesse o dashboard',
      description: 'Entre no UGC Control'
    },
    {
      icon: Sparkles,
      title: 'Organize toda sua rotina UGC',
      description: 'Comece a trabalhar de forma profissional'
    }
  ];

  return (
    <section className="relative py-24 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-950 to-gray-900" />

      <div className="relative max-w-6xl mx-auto z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-white">
          Como <span className="bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent">funciona?</span>
        </h2>

        <div className="grid md:grid-cols-5 gap-6">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="relative flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center mb-6 shadow-lg shadow-purple-500/30">
                  <Icon className="w-9 h-9 text-white" />
                </div>

                <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 h-full">
                  <div className="text-sm font-bold text-purple-300 mb-2">Passo {index + 1}</div>
                  <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-gray-400 text-sm">{step.description}</p>
                </div>

                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 -right-3 w-6 h-0.5 bg-gradient-to-r from-purple-500 to-transparent" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
