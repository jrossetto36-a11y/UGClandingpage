import { useRef } from 'react';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Solution from './components/Solution';
import HowItWorks from './components/HowItWorks';
import SocialProof from './components/SocialProof';
import TargetAudience from './components/TargetAudience';
import FinalOffer from './components/FinalOffer';
import Footer from './components/Footer';

function App() {
  const finalOfferRef = useRef<HTMLDivElement>(null);

  const handleHeroClick = () => {
    finalOfferRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCheckoutClick = () => {
    const checkoutUrl = 'https://pay.cakto.com.br/34kswm4_690413';
    window.open(checkoutUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Hero onCtaClick={handleHeroClick} />
      <PainPoints />
      <Solution />
      <HowItWorks />
      <SocialProof />
      <TargetAudience />
      <div ref={finalOfferRef}>
        <FinalOffer onCtaClick={handleCheckoutClick} />
      </div>
      <Footer />
    </div>
  );
}

export default App;
